//
//  AppDelegate.h
//  OnlinePerformanceMonitor
//
//  Created by xiaoshuang on 2019/8/26.
//  Copyright © 2019年 xiaoshuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

